// Bootstrap configuration information
var pcClientConfig={"serverName":"node1249","serverIP":"10.1.5.249","serverPort":"9191"};
